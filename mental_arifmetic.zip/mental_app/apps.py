from django.apps import AppConfig


class MentalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'mental_app'
