# This file makes the templatetags directory a Python package
